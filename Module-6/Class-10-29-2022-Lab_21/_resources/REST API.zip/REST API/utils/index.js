const jwt = require('./jwt');
const auth = require('./auth');

module.exports = {
    jwt,
    auth
};